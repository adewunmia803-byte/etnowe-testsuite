#!/bin/bash
# ============================================================
#  Etnowe Cross-App Regression — WELCOME10 Coupon Test Suite
#  Customer App:  com.teyematics.etnowe.uat
#  Merchant App:  com.teyematics.etnowemerchants.uat
#
#  Setup: Run `adb devices` first and paste your device IDs below
# ============================================================
set -e
set -o pipefail

# ─── CONFIGURE THESE BEFORE RUNNING ─────────────────────────
CUSTOMER_DEVICE="emulator-5554"   # adb devices → first emulator
MERCHANT_DEVICE="emulator-5556"   # adb devices → second emulator

CUSTOMER_A_EMAIL="customer_a@etnowe.com"
CUSTOMER_A_PASSWORD="Password1#"
CUSTOMER_B_EMAIL="customer_b@etnowe.com"
CUSTOMER_B_PASSWORD="Password1#"
MERCHANT_EMAIL="abasstoy14@gmail.com"
MERCHANT_PASSWORD="Password1#"
# ─────────────────────────────────────────────────────────────

BASE="e2e-test-suites-development"

# Helper: run a flow on the customer device
customer() {
  local FLOW=$1; shift
  echo "  📱 [CUSTOMER – $CUSTOMER_DEVICE] $FLOW"
  maestro --device "$CUSTOMER_DEVICE" test \
    "$BASE/etnowe-customer/flows/$FLOW" "$@"
}

# Helper: run a flow on the merchant device
merchant() {
  local FLOW=$1; shift
  echo "  🏪 [MERCHANT – $MERCHANT_DEVICE] $FLOW"
  maestro --device "$MERCHANT_DEVICE" test \
    "$BASE/etnowe-merchant/flows/$FLOW" "$@"
}

section() {
  echo ""
  echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
  echo "  $1"
  echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
}

# ════════════════════════════════════════════════════════════
section "A1 — First use of WELCOME10 succeeds"
# ════════════════════════════════════════════════════════════

# 1a. Merchant signs in and waits for incoming order
merchant signin_merchant.yaml \
  -e MERCHANT_EMAIL="$MERCHANT_EMAIL" \
  -e MERCHANT_PASSWORD="$MERCHANT_PASSWORD" &
MERCHANT_PID=$!

# 1b. Customer A places order with WELCOME10
customer coupon/A1_customer_first_use.yaml \
  -e CUSTOMER_A_EMAIL="$CUSTOMER_A_EMAIL" \
  -e CUSTOMER_A_PASSWORD="$CUSTOMER_A_PASSWORD"

# Wait for merchant signin to finish if still running
wait $MERCHANT_PID 2>/dev/null || true

# 1c. Merchant accepts the order
merchant accept_incoming_order.yaml

echo "✅ A1 PASSED"

# ════════════════════════════════════════════════════════════
section "A2 — Re-mint blocked after capture"
# ════════════════════════════════════════════════════════════

# 2a. Merchant marks order ready → triggers payment capture
merchant mark_ready_pickup.yaml

# 2b. Customer A tries WELCOME10 on a new order — must be blocked
customer coupon/A2_customer_remint_blocked.yaml

echo "✅ A2 PASSED"

# ════════════════════════════════════════════════════════════
section "A3 — Re-mint blocked while order still in-flight"
# ════════════════════════════════════════════════════════════
# Note: Merchant flows are intentionally NOT called after this —
# Order 1 must stay in-flight to validate the in-flight guard

customer coupon/A3_customer_inflight_blocked.yaml \
  -e CUSTOMER_A_EMAIL="$CUSTOMER_A_EMAIL" \
  -e CUSTOMER_A_PASSWORD="$CUSTOMER_A_PASSWORD"

echo "✅ A3 PASSED"

# ════════════════════════════════════════════════════════════
section "A4 — Different customer (B) is unaffected"
# ════════════════════════════════════════════════════════════
# A3 state is still active on CUSTOMER_DEVICE (Customer A locked)
# Customer B runs on MERCHANT_DEVICE — completely separate app session

echo "  ℹ️  Customer B runs on merchant device as a separate session"
maestro --device "$MERCHANT_DEVICE" test \
  "$BASE/etnowe-customer/flows/coupon/A4_customerB_unaffected.yaml" \
  -e CUSTOMER_B_EMAIL="$CUSTOMER_B_EMAIL" \
  -e CUSTOMER_B_PASSWORD="$CUSTOMER_B_PASSWORD"

echo "✅ A4 PASSED"

# ════════════════════════════════════════════════════════════
echo ""
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo "  ALL REGRESSION SCENARIOS PASSED ✅"
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
